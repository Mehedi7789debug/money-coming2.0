Place optimized images here. Prefer WebP/AVIF where supported and lazy-load non-critical images.
