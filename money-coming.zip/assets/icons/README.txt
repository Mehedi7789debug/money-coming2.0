Place small SVG/PNG UI icons here. Avoid huge assets for low-end Android performance.
